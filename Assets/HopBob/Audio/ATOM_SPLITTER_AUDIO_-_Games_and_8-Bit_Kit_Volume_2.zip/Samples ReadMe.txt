These samples are made by AtomSplitter -

http://www.atomsplitteraudio.com

They are royalty free and can be used in your music production, however they may not be re-packaged or sold, if you make lots of money with them a donation would be great to help towards site costs and future developments but is of course optional. Many thanks, hope you enjoy them.